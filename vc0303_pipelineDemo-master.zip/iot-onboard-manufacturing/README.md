# Car Simulator

Run index.html in browser to run the car simulator. 

To update the credentials, navigate to js/realtime.js and update the 

```javascript
var orgId = "4nlxt2"; // your org ID
var deviceType = "car"; // your device Type
var deviceId = "011023"; // Your device ID
var deviceToken = "adfF?aTNEx3bn&T9Gk"; // Your device Token
```
